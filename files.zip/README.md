# 🚖 Quản Lý Tài Xế 2026

App quản lý tài xế, doanh thu, quỹ và lịch trực với cloud database.

## ✨ Tính năng

- 📊 Dashboard tổng quan doanh thu, top tài xế, biểu đồ
- 👥 Quản lý 27+ tài xế: thông tin, CCCD, dằn cọc, tiền áo
- 💰 Nhập đơn hàng ngày — tự tính chiết khấu 20% và phí
- 💼 Quản lý quỹ: phạt tài xế, chi hoạt động, chi marketing
- 📅 Lịch trực 3 ca (sáng/chiều/tối)
- 📈 Báo cáo & xếp hạng + xuất Excel
- ☁️ Dữ liệu lưu trên Supabase Cloud — real-time sync mọi thiết bị

## 🚀 Công nghệ

- React 18 (CDN)
- Supabase (PostgreSQL + Realtime)
- SheetJS (xuất Excel)
- Vercel (hosting)

## 📱 Cách dùng trên điện thoại

Mở link trên Chrome/Safari → Menu → **Add to Home Screen** để dùng như app native.

## 🌐 Database

Bảng `tx_*` trên Supabase:
- `tx_drivers` — tài xế
- `tx_revenue` — doanh thu
- `tx_penalties` — phạt
- `tx_expenses` — chi quỹ
- `tx_schedule` — lịch trực
- `tx_config` — cấu hình

---
© 2026 — Built with Claude
